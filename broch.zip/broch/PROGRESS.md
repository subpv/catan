# Broch – Fortschritt und Testliste

## So testest du
- Lobby: „New game“ → Modus wählen → „Create“ → mit „🤖 Add bot“ Bots dazunehmen (oder „Fill free seats with bots“) → „Start game“. Ohne Bots startest du nur mit echten Spielern (auf dem echten Server); in dieser Demo gibt es nur dich und Bots.
- Das „?“ auf jeder Kachel startet das Tutorial des Modus (rund 1 Minute, mit Bildern).
- Im Spiel: Handel → „Offer a trade“; die anderen können annehmen, ablehnen oder ein Gegenangebot machen.
- Spiele mit Bots zählen nicht für die Statistik.

## Modi

| Modus | Status | Was testen | Bekannte Lücken |
|---|---|---|---|
| Classic (3–6 Spieler) | fertig | Aufbau, Handel inkl. Gegenangebot, 7 würfeln, Entwicklungskarten, 5–6 Spieler mit zwei Steinen (Stein 1 würfelt, Stein 2 nur Bank). | – |
| Cities & Knights | fertig | Ritter, Stadtausbau, Barbaren, Fortschrittskarten, Aquädukt (einmal wählen, dann automatisch), Metropole. | – |
| New Energies | fertig | Kraftwerke, Ereignis-Chips, Umweltbilanz, Inspektor bei der 7, Handel mit Gegenangebot. | – |
| Rise of the Inkas | fertig | Stämme, Verfall mit Dornen, neuer Stamm, Handelsgüter-Tausch 3:2, Kampfkunst-Karten, Zufallslandschaft (Lobby-Schalter). | Die 2 reinen Ozeanfelder des echten Bretts sind nicht gezeichnet (keine Regelwirkung). |
| Seafarers | **Beta** | Schiffe, Inseln, Nebel, Szenarien aus dem Regelbuch. | Szenario 7 fehlt; Hafentypen nicht belegt. |
| Traders & Barbarians | **Beta** | Fischfang, Flüsse, Merchant Trains (Abstimmung, Wagen), Barbarenüberfall, Wagen-Szenario, Ereigniskarten, Freundlicher Räuber, Häfen; alle auch mit 5–6 Spielern. | Die 12 Zusatzkarten der 5–6-Box sind ein Platzhalter; Catan for Two fehlt; einige Bretter (Brückenplätze, Fischgründe 5–6) aus Bildern gelesen. |
| Explorers & Pirates | **Beta** | Schiffe ziehen, Entdecker, Piratenlager, Fische, Gewürze, 5 Szenarien, 5–6 Spieler (Schiff 1 / Schiff 2). | Zahlen der Piratenlager der Grundbox unbekannt (die 5–6-Lager haben 9 und 10 laut Besitzer). |
| Dawn of Humankind | **Beta** | Weltkarte, Lager, Entdecker, Bedrohung, Fortschrittsleisten. | Brett aus den Buchbildern gelesen. |

## Neu
- Gegenangebote beim Handel in allen Spielen.
- Bots: Host fügt sie in der Lobby hinzu (Gamer-Namen wie SnazzyTurnip); echter Server und Demo.
- Inka nach dem Almanach: Vorrat 20/12, Stapel 7+3, 3 Güter → 2 Rohstoffe, Gründung ohne Straße, Zufallslandschaft.
- Händler & Barbaren nach dem englischen Buch (6. Ausgabe): Kartenstapel, Wagen, Barbarenüberfall, Merchant Trains, 5–6-Spieler-Bretter.
- Beta-Schilder auf den Modi, bei denen noch Informationen fehlen.
- Alle Tutorials und Info-Texte wurden gegen die geänderten Regeln geprüft und angepasst (Handel, 5–6, Aquädukt, Metropole, Almanach …).

## Was mir noch fehlt
- Händler & Barbaren 5–6: Foto/Liste der 12 Zusatzkarten.
- Entdecker & Piraten: Zahlen der 6 Piratenlager der Grundbox (Foto der Plättchen).
- Optional: englische Bücher zu Entdecker & Piraten und Seefahrer, Fotos der Aufbruch-der-Menschheit-Karten.
